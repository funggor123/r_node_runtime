package main

import (
	"math/rand"
	"time"
)

func main() {
	rand.Seed(time.Now().UTC().UnixNano())

	configer = getConfiger()
	logger = getLogger()

	// Read Configuration
	configer.readConfigs()

	// Check configuration
	configer.checkPathsAndFilesExists()

	// Set Logger
	logger.setLogFilePath(configer.config.LogDir)

	// Print Configs
	configer.printConfigs()

	// Start Router
	startRouter()

}
