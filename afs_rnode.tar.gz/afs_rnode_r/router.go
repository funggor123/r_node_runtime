package main

import (
	"github.com/gin-gonic/gin"
)

func setGin() {
	gin.SetMode(GIN_MODE)
}

func startRouter() {

	setGin()
	r := gin.New()

	route_register(r, getNode())

	r.Run(":" + getConfiger().config.Port)
}

func route_register(router *gin.Engine, node *Node) {

	// v1 //

	v1 := router.Group(URL_GROUP_V1)
	{
		rn := v1.Group(URL_GROUP_RNODE)
		{
			rn.GET(URL_PROB, node.probe)
			rn.POST(URL_UPLOAD, node.uploadFile)
			rn.GET(URL_DOWNLOAD, node.downloadFile)
			rn.POST(URL_NOTIFY, node.notify)
			exists := rn.Group(URL_GROUP_EXISTS)
			{
				exists.GET(URL_MD5, node.checkfileExistsByMd5)
				exists.GET(URL_AFID, node.checkfileExistsByAfid)
			}
		}
	}

	node.Upload = URL_GROUP_V1 + URL_GROUP_RNODE + URL_UPLOAD
	node.Donwload = URL_GROUP_V1 + URL_GROUP_RNODE + URL_DOWNLOAD
	node.Notify = URL_GROUP_V1 + URL_GROUP_RNODE + URL_NOTIFY
	node.Prob = URL_GROUP_V1 + URL_GROUP_RNODE + URL_PROB
	node.Exists_afid = URL_GROUP_V1 + URL_GROUP_RNODE + URL_GROUP_EXISTS + URL_AFID
	node.Exists_md5 = URL_GROUP_V1 + URL_GROUP_RNODE + URL_GROUP_EXISTS + URL_MD5
}
