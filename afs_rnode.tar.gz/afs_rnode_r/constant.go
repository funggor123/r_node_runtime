package main

import "github.com/gin-gonic/gin"

// common
const NODE_NAME = "Retreivel Node"

// configer.go
const CONFIG_FILE_NAME = "conf.json"
const KEY_PAIR_TABLE = "key_pair"

// logger.go
const LOG_FILE_FORMAT = ".log"
const DEBUG_MSG_ERROR = "[Error]"
const DEBUG_MSG_TRACK = "[Track]"

const (
	SHOW_ERROR_AND_TRACK = iota
	SHOW_TRACK           = iota
)

const (
	ERROR = iota
	TRACK = iota
)

// router.go
const GIN_MODE = gin.ReleaseMode

//const expireDayMin = 3
