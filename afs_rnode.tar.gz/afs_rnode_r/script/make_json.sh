#!/bin/bash

# Define
# Write configuration file
cat <<EOF > conf.json
{ "x64_program_path": "$x64_program_path", 
  "x64_program_name": "$x64_program_name", 
  "port": "$host_port", 
  "upload_dir": "/upload/",
  "download_dir": "/download/",
  "log_dir": "$log_path" 
}
EOF

mv conf.json .. 
                                                                         
