package main

import (
	"os"
	"os/exec"
)

func runBashComamnd(command string) (string, error) {

	var cmd *exec.Cmd
	var commandResult []byte
	var err error

	cmd = exec.Command("./"+getConfiger().config.AfsProgramName, command)
	cmd.Dir = getConfiger().config.AfsProgramPath
	if commandResult, err = cmd.CombinedOutput(); err != nil {
		getLogger().log(ERROR, err)
		return "", err
	}

	/*
		getLogger().log(TRACK, "[Command]",
			getConfiger().config.AfsProgramPath+getConfiger().config.AfsProgramName+" "+"\""+command+"\"")
	*/

	return string(commandResult), nil
}

func deleteFile(filePath string, fileName string) error {
	err := os.Remove(filePath + fileName)
	if err != nil {
		return err
	}
	return nil
}

func deleteFileFullPath(fileFullPath string) error {
	err := os.Remove(fileFullPath)
	if err != nil {
		return err
	}
	return nil
}

func openFile(filePath string, fileName string) (*os.File, error) {
	file, err := os.Open(filePath + fileName)
	if err != nil {
		return file, err
	}
	return file, nil
}

func openFileFullPath(fileFullPath string) (*os.File, error) {
	file, err := os.Open(fileFullPath)
	if err != nil {
		return file, err
	}
	return file, nil
}

func isFileExists(filePath string, fileName string) bool {

	_, err := openFile(filePath, fileName)
	if err != nil {
		return false
	}
	return true
}

func terminateProg(err error) {
	getLogger().stdPrint(ERROR, err.Error())
	os.Exit(3)
}

func isDirExists(dirPath string, isCreate bool) bool {

	if _, err := os.Stat(dirPath); os.IsNotExist(err) {
		if isCreate {
			os.Mkdir(dirPath, 0755)
			return true
		}
		getLogger().stdPrint(ERROR, err.Error())
		return false
	}
	return true
}

func getFileSize(f *os.File) (int64, error) {
	fi, err := f.Stat()
	if err != nil {
		return 0, err
	}
	return fi.Size(), nil
}
