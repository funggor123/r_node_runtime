package main

import (
	"encoding/json"
	"errors"
	"os"
)

type Configuration struct {
	AfsProgramPath string `json:"x64_program_path" binding:"required"`
	AfsProgramName string `json:"x64_program_name" binding:"required"`
	Port           string `json:"port" binding:"required"`
	UploadDir      string `json:"upload_dir" binding:"required"`
	DownloadDir    string `json:"download_dir" binding:"required"`
	LogDir         string `json:"log_dir" binding:"required"`
}

type Configer struct {
	config Configuration
}

type RNode struct {
	Address string `json:"address" binding:"required"`
}

var configer *Configer

func getConfiger() *Configer {
	if configer != nil {
		return configer
	}
	return new(Configer)
}

func (configer *Configer) readConfigs() {

	file, err := os.Open(CONFIG_FILE_NAME)
	defer file.Close()
	if err != nil {
		terminateProg(err)
	}

	decoder := json.NewDecoder(file)
	configuration := Configuration{}
	if err = decoder.Decode(&configuration); err != nil {
		terminateProg(err)
	}

	configer.config = configuration
}

func (configer Configer) checkPathsAndFilesExists() {

	exists := true

	_ = isDirExists(configer.config.LogDir, true)
	_ = isDirExists("./"+configer.config.UploadDir, true)
	_ = isDirExists("./"+configer.config.DownloadDir, true)

	exists = isFileExists(configer.config.AfsProgramPath, configer.config.AfsProgramName)

	if !exists {
		terminateProg(errors.New("Some Paths or Files specified in configuration file not exists"))
	}
}

func (configer Configer) printConfigs() {
	if &configer.config != nil {
		getLogger().log(TRACK, "configs -", configer.config)
	}
}
