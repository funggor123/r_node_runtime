package main

import (
	"fmt"
	"io/ioutil"
	"net/http"

	"github.com/gin-gonic/gin"
)

type Node struct {
	Upload      string `json:"upload" binding:"required"`
	Donwload    string `json:"download" binding:"required"`
	Notify      string `json:"notify" binding:"required"`
	Exists_afid string `json:"exists_afid" binding:"required"`
	Exists_md5  string `json:"exists_md5" binding:"required"`
	Prob        string `json:"prob" binding:"required"`
}

var node *Node

func getNode() *Node {
	if node != nil {
		return node
	}
	node = new(Node)
	return node
}

func (node Node) probe(c *gin.Context) {
	c.JSON(http.StatusOK, getNode())
}

func (node Node) notify(c *gin.Context) {

	afid := c.Request.FormValue("afid")
	command := ";_f=notify;afid=" + afid + ";"
	getLogger().log(TRACK, "|", getCurrentIP(*c.Request), "|", "afid -", afid)
	getLogger().log(TRACK, "|", getCurrentIP(*c.Request), "|", "command -", command)

	result, err := runBashComamnd(command)
	getLogger().log(TRACK, "|", getCurrentIP(*c.Request), "|", "command result -", result)

	if err != nil {
		getLogger().log(TRACK, "|", getCurrentIP(*c.Request), "|", "error -", err.Error())
		c.JSON(http.StatusInternalServerError, NotifyResponse{IsError: true})
		return
	}

	c.JSON(http.StatusOK, parseNotifyResponse(result))
}

func (node Node) checkfileExistsByMd5(c *gin.Context) {

	md5 := c.Query("md5")
	command := ";_f=query;md5=" + md5 + ";"
	getLogger().log(TRACK, "|", getCurrentIP(*c.Request), "|", "md5 -", md5)
	getLogger().log(TRACK, "|", getCurrentIP(*c.Request), "|", "command -", command)

	result, err := runBashComamnd(command)
	getLogger().log(TRACK, "|", getCurrentIP(*c.Request), "|", "command result -", result)

	if err != nil {
		getLogger().log(TRACK, "|", getCurrentIP(*c.Request), "|", "error -", err.Error())
		c.JSON(http.StatusInternalServerError, QueryResponse{IsError: true})
		return
	}

	c.JSON(http.StatusOK, parseQueryResponse(result))
}

func (node Node) checkfileExistsByAfid(c *gin.Context) {

	afid := c.Query("afid")
	command := ";_f=query;afid=" + afid + ";"
	getLogger().log(TRACK, "|", getCurrentIP(*c.Request), "|", "afid -", afid)
	getLogger().log(TRACK, "|", getCurrentIP(*c.Request), "|", "command -", command)

	result, err := runBashComamnd(command)
	getLogger().log(TRACK, "|", getCurrentIP(*c.Request), "|", "command result -", result)

	if err != nil {
		getLogger().log(TRACK, "|", getCurrentIP(*c.Request), "|", "error -", err.Error())
		c.JSON(http.StatusInternalServerError, QueryResponse{IsError: true})
		return
	}
	c.JSON(http.StatusOK, parseQueryResponse(result))
}

func (node Node) uploadFile(c *gin.Context) {

	expiredDate := c.Request.FormValue("exp_date")

	file, err := c.FormFile("file")
	if err != nil {
		getLogger().log(TRACK, "|", getCurrentIP(*c.Request), "|", "error -", err.Error())
		c.JSON(http.StatusInternalServerError, UploadResponse{IsError: true})
		return
	}

	getLogger().log(TRACK, "|", getCurrentIP(*c.Request), "|", "file size -", file.Size)

	currentDir, err := getCurrentProgramPath()
	if err != nil {
		getLogger().log(TRACK, "|", getCurrentIP(*c.Request), "|", "error -", err.Error())
		c.JSON(http.StatusInternalServerError, UploadResponse{IsError: true})
		return
	}

	tempFileDir := currentDir + getConfiger().config.UploadDir
	tempFileName := RandStringRunes(10) + ".temp"

	if err := c.SaveUploadedFile(file, tempFileDir+tempFileName); err != nil {
		getLogger().log(TRACK, "|", getCurrentIP(*c.Request), "|", "error -", err.Error())
		c.JSON(http.StatusInternalServerError, UploadResponse{IsError: true})
		return
	}
	defer deleteFile(tempFileDir, tempFileName)

	var command = ""
	if expiredDate != "-1" {
		command = ";_f=upload;local_file=" + tempFileDir + tempFileName + ";" + "time_stamp_expired=" + expiredDate + ";"
	} else {
		command = ";_f=upload;local_file=" + tempFileDir + tempFileName + ";"
	}

	getLogger().log(TRACK, "|", getCurrentIP(*c.Request), "|", "command -", command)

	result, err := runBashComamnd(command)
	getLogger().log(TRACK, "|", getCurrentIP(*c.Request), "|", "command result -", result)

	if err != nil {
		getLogger().log(TRACK, "|", getCurrentIP(*c.Request), "|", "error -", err.Error())
		c.JSON(http.StatusInternalServerError, UploadResponse{IsError: true})
		return
	}

	c.JSON(http.StatusOK, parseUploadResponse(result))

}

func (node Node) downloadFile(c *gin.Context) {

	afid := c.Query("afid")
	download_filename := c.Query("download_filename")
	getLogger().log(TRACK, "|", getCurrentIP(*c.Request), "|", "afid -", afid, "|", "download_filename -", download_filename)

	currentDir, err := getCurrentProgramPath()
	if err != nil {
		getLogger().log(TRACK, "|", getCurrentIP(*c.Request), "|", "error -", err.Error())
		c.JSON(http.StatusInternalServerError, DownloadResponse{IsError: true})
		return
	}

	tempFileDir := currentDir + getConfiger().config.DownloadDir
	tempFileName := RandStringRunes(10) + ".temp"

	var command = ";_f=download;afid=" + afid + ";local_file=" + tempFileDir + tempFileName + ";"

	getLogger().log(TRACK, "|", getCurrentIP(*c.Request), "|", "command result -", command)
	result, err := runBashComamnd(command)
	getLogger().log(TRACK, "|", getCurrentIP(*c.Request), "|", "command result -", result)

	if err != nil {
		getLogger().log(TRACK, "|", getCurrentIP(*c.Request), "|", "error -", err.Error())
		c.JSON(http.StatusInternalServerError, DownloadResponse{IsError: true})
		return
	}

	if isFail(result) {
		getLogger().log(TRACK, "|", getCurrentIP(*c.Request), "|", "error -", result)
		c.JSON(http.StatusBadRequest, parseDownloadResponse(result))
		return
	}

	defer deleteFile(tempFileDir, tempFileName)

	dat, err := ioutil.ReadFile(tempFileDir + tempFileName)
	if err != nil {
		getLogger().log(TRACK, "|", getCurrentIP(*c.Request), "|", "error -", err.Error())
		c.JSON(http.StatusInternalServerError, DownloadResponse{IsError: true})
		return
	}
	getLogger().log(TRACK, "|", getCurrentIP(*c.Request), "|", "file size -", len(dat))

	c.Writer.WriteHeader(http.StatusOK)
	c.Header("Content-Disposition", "attachment; filename="+download_filename)
	c.Header("Content-Type", "application/text/plain")
	c.Header("Accept-Length", fmt.Sprintf("%d", len(dat)))
	c.Writer.Write(dat)
}
