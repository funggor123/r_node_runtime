package main

import (
	"math/rand"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"
)

func getCurrentTime() string {
	current_time := time.Now().Local()
	timeString := current_time.Format("Mon Jan _2 15:04:05 2006")
	return timeString
}

func getCurrentTimeInRFC() string {
	return time.Now().Format("2006-01-02T15:04:05")
}

func getCurrentProgramPath() (string, error) {
	dir, err := filepath.Abs(filepath.Dir(os.Args[0]))
	if err != nil {
		return dir, err
	}
	return dir, nil
}

var letterRunes = []rune("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")

func RandStringRunes(n int) string {
	b := make([]rune, n)
	for i := range b {
		b[i] = letterRunes[rand.Intn(len(letterRunes))]
	}
	return string(b)
}

func getCurrentIP(r http.Request) string {
	ip := r.Header.Get("X-Real-IP")
	if ip == "" {
		ip = strings.Split(r.RemoteAddr, ":")[0]
	}
	return ip
}
