package main

import (
	"strings"
)

type DownloadResponse struct {
	Message string `json:"message" binding:"required"`
	IsError bool   `json:"is_error" binding:"required"`
}

type QueryResponse struct {
	IsExists bool   `json:"is_exists" binding:"required"`
	IsCache  bool   `json:"is_cache" binding:"required"`
	IsError  bool   `json:"is_error" binding:"required"`
	Message  string `json:"message" binding:"required"`
}

type UploadResponse struct {
	Afid     string `json:"result" binding:"required"`
	Message  string `json:"message" binding:"required"`
	IsError  bool   `json:"is_error" binding:"required"`
	IsExists bool   `json:"is_exists" binding:"required"`
	IsCache  bool   `json:"is_cache" binding:"required"`
}

type NotifyResponse struct {
	IsError bool   `json:"is_error" binding:"required"`
	Message string `json:"message" binding:"required"`
}

func isFail(line string) bool {
	if strings.Contains(line, "_r=false") {
		return true
	}
	return false
}
func parseDownloadResponse(line string) DownloadResponse {
	var downloadResponse DownloadResponse
	if strings.Contains(line, "_r=false") {
		downloadResponse.IsError = true
		downloadResponse.Message = line
	} else {
		downloadResponse.IsError = false
	}
	return downloadResponse
}

func parseNotifyResponse(line string) NotifyResponse {
	var notifyResponse NotifyResponse
	if strings.Contains(line, "_r=false") {
		notifyResponse.IsError = true
		notifyResponse.Message = line
	} else {
		notifyResponse.IsError = false
	}
	return notifyResponse
}

func parseUploadResponse(line string) UploadResponse {
	var uploadResponse UploadResponse
	if strings.Contains(line, "_r=false") {
		uploadResponse.IsError = true
		uploadResponse.Message = line
	} else {
		uploadResponse.IsError = false
	}

	if strings.Contains(line, ";afid=") {
		afidStartIndex := strings.Index(line, ";afid=") + len(";afid=")
		afidLength := 128
		uploadResponse.Afid = line[afidStartIndex : afidStartIndex+afidLength]
	}

	if strings.Contains(line, ";is_exist=") {
		startIndex := strings.Index(line, ";is_exist=") + len(";is_exist=")
		if line[startIndex:startIndex+5] == "false" {
			uploadResponse.IsExists = false
		} else {
			uploadResponse.IsExists = true
		}
	}

	if strings.Contains(line, ";is_cache=") {
		startIndex := strings.Index(line, ";is_cache=") + len(";is_cache=")
		if line[startIndex:startIndex+5] == "false" {
			uploadResponse.IsCache = false
		} else {
			uploadResponse.IsCache = true
		}
	}

	return uploadResponse
}

func parseQueryResponse(line string) QueryResponse {
	var queryResponse QueryResponse
	if strings.Contains(line, ";is_exist=") {
		startIndex := strings.Index(line, ";is_exist=") + len(";is_exist=")
		if line[startIndex:startIndex+5] == "false" {
			queryResponse.IsExists = false
		} else {
			queryResponse.IsExists = true
		}
	}

	if strings.Contains(line, ";is_cache=") {
		startIndex := strings.Index(line, ";is_cache=") + len(";is_cache=")
		if line[startIndex:startIndex+5] == "false" {
			queryResponse.IsCache = false
		} else {
			queryResponse.IsCache = true
		}
	}

	if strings.Contains(line, "_r=false") {
		queryResponse.IsError = true
		queryResponse.Message = line
	} else {
		queryResponse.IsError = false
	}

	return queryResponse
}
